<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
{{-- <link rel="stylesheet" href="<?= //url('assets/bootstrap_4.4.1/css/bootstrap.min.css') ?>"> --}}
<!-- Bootstrap CSS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Select CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css" rel="stylesheet">
<!-- <script src="assets/bootstrap_4.4.1/js/bootstrap.min.js"></script> -->

<script src="<?= url('assets/js/sweetalert2.min.js') ?>"></script>
<link rel="stylesheet" href="<?= url('assets/css/sweetalert2.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">


