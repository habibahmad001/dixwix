<script>
    function openNav() {
        document.getElementById("filterSideBar").style.width = "250px";
    }

    /* Set the width of the sidebar to 0 (hide it) */
    function closeNav() {
        document.getElementById("filterSideBar").style.width = "0";
    } 
</script>