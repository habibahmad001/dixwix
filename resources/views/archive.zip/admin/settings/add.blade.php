<div class="container">
    <div class="heading">
        <h2>{{ $data["title"] }}</h2>
    </div>
    <div class="divider">
        <hr>
    </div>
    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif
    @if(session()->has('error'))
    <div class="alert alert-danger">
        {{ session()->get('error') }}
    </div>
    @endif
    <form class="main-form" name="add-type-form" enctype="multipart/form-data" id="add-type-form" method="post"
          action="{{ route('store-settings') }}">
        @csrf
        <input type="hidden" name="mode" value="{{ $mode }}">
        <input type="hidden" name="setting_id" value="{{ $setting_id ?? '' }}">

        <div class="form-group">
            <input type="text" class="form-control" id="title" name="name"
                   value="{{ old('name', $setting['name'] ?? '') }}" placeholder="Settings Name">
            @error('name')
            <div class="error_msg">*{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <input type="text" class="form-control" id="value" name="value"
                   value="{{ old('value', $setting['value'] ?? '') }}" placeholder="Settings Value">
            @error('value')
            <div class="error_msg">*{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <button type="submit" class="btn lastbtn submit_btn">Submit</button>
        </div>
        @if (session('error'))
        <div class="error_msg">*{{ session('error') }}</div>
        @endif
    </form>
</div>
