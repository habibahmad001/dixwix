<table id="items_table" class="table">
    <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Value</th>
            <th scope="col">Date Added</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($data["settings"] as $setting){ ?>
            <tr>
                <td><?=$setting->name?></td>
                <td><?=$setting->value?></td>
                <td><?=date("m/d/Y",strtotime($setting->created_at))?></td>
                <td><a href="<?=route("edit-settings",["id"=>$setting->id])?>"><img src="<?=url("assets/media/edit-orange.png")?>" width="15px" height="15px"/></a></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
