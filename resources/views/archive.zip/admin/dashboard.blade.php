<div class="container">
  <div class="row">
    <div class="col-md-4">
      <div class="bg-gray">
        <h3>Total number of </h3>
        <p class="one">Groups</p>
        <p class="number1"><?=count($data['groups'])?></p>
        <div class="imgsecdiv">
        <img src="assets/media/userimg.png" class="se9img">
        </div>
      </div>
      </div>
    <!-- <div class="col-md-4">
      <div class="bg-gray">
        <h3>Total items by </h3>
        <p class="one">Categories</p>
        <div>
        <img src="assets/media/graf.png" class="se9img">
        </div>
      </div>
    </div> -->
    <!-- <div class="col-md-4">
      <div class="bg-gray">
        <h3>Total</h3>
        <p class="one">Rewards</p>
        <p class="number1">2034</p>
        <div class="imgsecdiv">
        <img src="assets/media/reward.png" class="se9img lastimg">
        </div>
      </div>
  </div> -->
</div>
</div>

<!-- <div class="container">
  <div class="heading"><h2>New groups</h2></div>
  <div class="row">
    <div class="MultiCarousel" data-items="1,3,5,6,1" data-slide="1" id="MultiCarousel"  data-interval="1000">
      <div class="MultiCarousel-inner">
          <div class="item">
              <div class="pad15">

                <div class="innerheader">
                  <h3 class="lead main-heading">Club Read 2024</h3>
                  <div class="post_image">
                    <img src="assets/media/eye-outline.png" alt="Book Image">
                    <img src="assets/media/log-out-outline.png" alt="Book Image">

                  </div>

                </div>
                  

              <div class="divider"><hr></div>

              <div class="carousel-date">Created: 2023-05-25</div>
              <div class="member">Members: 12</div>

              <div class="imagesection">
                <img class="im-wd" src="assets/media/bookcover.png" alt="Book Image">
                <a id="edit_item" href="#" class="btn link_with_img">
                  <img src="assets/media/add-circle-outline.png"> join now
                </a>
              
              
              </div>
              </div>
              
          </div>
          <div class="item">
            <div class="pad15">

              <div class="innerheader">
                <h3 class="lead main-heading">Social group</h3>
                <div class="post_image">
                  <img src="assets/media/eye-outline.png" alt="Book Image">
                  <img src="assets/media/log-out-outline.png" alt="Book Image">

                </div>

              </div>
                

            <div class="divider"><hr></div>

            <div class="carousel-date">Created: 2023-05-25</div>
            <div class="member">Members: 12</div>

            <div class="imagesection">
              <img class="im-wd" src="assets/media/bookcover.png" alt="Book Image">
              <a id="edit_item" href="#" class="btn link_with_img">
                <img src="assets/media/add-circle-outline.png"> join now
              </a>
            
            
            </div>
            </div>
            
          </div>
          <div class="item">
            <div class="pad15">

              <div class="innerheader">
                <h3 class="lead main-heading">2024 ROOT Challenge</h3>
                <div class="post_image">
                  <img src="assets/media/eye-outline.png" alt="Book Image">
                  <img src="assets/media/log-out-outline.png" alt="Book Image">

                </div>

              </div>
                

            <div class="divider"><hr></div>

            <div class="carousel-date">Created: 2023-05-25</div>
            <div class="member">Members: 12</div>

            <div class="imagesection">
              <img class="im-wd" src="assets/media/bookcover.png" alt="Book Image">
              <a id="edit_item" href="#" class="btn link_with_img">
                <img src="assets/media/add-circle-outline.png">  join now
              </a>
            
            
            </div>
            </div>
            
          </div>
          <div class="item">
              <div class="pad15">

                <div class="innerheader">
                  <h3 class="lead main-heading">Social group</h3>
                  <div class="post_image">
                    <img src="assets/media/eye-outline.png" alt="Book Image">
                    <img src="assets/media/log-out-outline.png" alt="Book Image">

                  </div>

                </div>
                  

              <div class="divider"><hr></div>

              <div class="carousel-date">Created: 2023-05-25</div>
              <div class="member">Members: 12</div>

              <div class="imagesection">
                <img class="im-wd" src="assets/media/bookcover.png" alt="Book Image">
                <a id="edit_item" href="#" class="btn link_with_img">
                  <img src="assets/media/add-circle-outline.png">  join now
                </a>
              
              
              </div>
              </div>
              
          </div>
          <div class="item">
            <div class="pad15">

              <div class="innerheader">
                <h3 class="lead main-heading">Social group</h3>
                <div class="post_image">
                  <img src="assets/media/eye-outline.png" alt="Book Image">
                  <img src="assets/media/log-out-outline.png" alt="Book Image">

                </div>

              </div>
                

            <div class="divider"><hr></div>

            <div class="carousel-date">Created: 2023-05-25</div>
            <div class="member">Members: 12</div>

            <div class="imagesection">
              <img class="im-wd" src="assets/media/bookcover.png" alt="Book Image">
              <a id="edit_item" href="#" class="btn link_with_img">
                <img src="assets/media/add-circle-outline.png">  join now
              </a>
            
            
            </div>
            </div>
            
          </div>
      </div>
            <button class="btn-primary leftLst"><</button>
            <button class="btn-primary rightLst">></button>
    </div>
  </div>
</div> -->

<!-- <div class="container">
  <div class="heading"><h2>New items</h2></div>
  <div class="divider"><hr></div>
  <div class="row">
    <div class="MultiCarousel" data-items="1,3,5,6,1" data-slide="1" id="MultiCarousel"  data-interval="1000">
        <div class="MultiCarousel-inner">
          <div class="item">
              <div class="pad15">

                <div class="eye"><img src="assets/media/eye-outline.png" alt="Book Image"></div>

                <div class="who-sce">

                  <div class="imagediv"> 
                    <img src="assets/media/theceo.png">
                  </div>


                  <div class="textrow">
                    <div class="hed1">CEO of YOU</div>
                    <div class="hed2">Marsha Petrie Sue <br> <span style="font-size: 11px; color: #094042; font-weight: 800;">2005</span></div>
                    <div class="head3"> 231 pages(Communicating Results Press)</div>
                    <div class="head4"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Added:</span>2018-10-13</div>
                    <div class="head5"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Group:</span>2018-10-13</div>
                  </div>
                </div>

                <div class="post_image imagebg">
                  <img src="assets/media/add-circle-outline7.png" alt="Book Image">
                  <img src="assets/media/trash-outline.png" alt="Book Image">

                </div>

              </div>
              
          </div>

          <div class="item">
              <div class="pad15">

                <div class="eye"><img src="assets/media/eye-outline.png" alt="Book Image"></div>

                <div class="who-sce">

                  <div class="imagediv"> 
                    <img src="assets/media/theceo.png">
                  </div>


                  <div class="textrow">
                    <div class="hed1">CEO of YOU</div>
                    <div class="hed2">Marsha Petrie Sue <br> <span style="font-size: 11px; color: #094042; font-weight: 800;">2005</span></div>
                    <div class="head3"> 231 pages(Communicating Results Press)</div>
                    <div class="head4"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Added:</span>2018-10-13</div>
                    <div class="head5"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Group:</span>2018-10-13</div>
                  </div>
                </div>

                <div class="post_image imagebg">
                  <img src="assets/media/add-circle-outline7.png" alt="Book Image">
                  <img src="assets/media/trash-outline.png" alt="Book Image">

                </div>
                
              </div>
              
          </div>

          <div class="item">
              <div class="pad15">

                <div class="eye"><img src="assets/media/eye-outline.png" alt="Book Image"></div>

                  <div class="who-sce">

                    <div class="imagediv"> 
                      <img src="assets/media/theceo.png">
                    </div>


                    <div class="textrow">
                      <div class="hed1">CEO of YOU</div>
                      <div class="hed2">Marsha Petrie Sue <br> <span style="font-size: 11px; color: #094042; font-weight: 800;">2005</span></div>
                      <div class="head3"> 231 pages(Communicating Results Press)</div>
                      <div class="head4"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Added:</span>2018-10-13</div>
                      <div class="head5"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Group:</span>2018-10-13</div>
                    </div>
                  </div>

                  <div class="post_image imagebg">
                    <img src="assets/media/add-circle-outline7.png" alt="Book Image">
                    <img src="assets/media/trash-outline.png" alt="Book Image">

                  </div>

                  

              </div>
              
          </div>
          <div class="item">
              <div class="pad15">

                <div class="eye"><img src="assets/media/eye-outline.png" alt="Book Image"></div>

                <div class="who-sce">

                  <div class="imagediv"> 
                    <img src="assets/media/theceo.png">
                  </div>


                  <div class="textrow">
                    <div class="hed1">CEO of YOU</div>
                    <div class="hed2">Marsha Petrie Sue <br> <span style="font-size: 11px; color: #094042; font-weight: 800;">2005</span></div>
                    <div class="head3"> 231 pages(Communicating Results Press)</div>
                    <div class="head4"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Added:</span>2018-10-13</div>
                    <div class="head5"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Group:</span>2018-10-13</div>
                  </div>
                </div>

                <div class="post_image imagebg">
                  <img src="assets/media/add-circle-outline7.png" alt="Book Image">
                  <img src="assets/media/trash-outline.png" alt="Book Image">

                </div>

              </div>
              
          </div>
          <div class="item">
            <div class="pad15">
              <div class="eye"><img src="assets/media/eye-outline.png" alt="Book Image"></div>

              <div class="who-sce">

                <div class="imagediv"> 
                  <img src="assets/media/theceo.png">
                </div>


                <div class="textrow">
                  <div class="hed1">CEO of YOU</div>
                  <div class="hed2">Marsha Petrie Sue <br> <span style="font-size: 11px; color: #094042; font-weight: 800;">2005</span></div>
                  <div class="head3"> 231 pages(Communicating Results Press)</div>
                  <div class="head4"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Added:</span>2018-10-13</div>
                  <div class="head5"> <span style="font-size: 11px; color: #094042; font-weight: 800;">Group:</span>2018-10-13</div>
                </div>
              </div>

              <div class="post_image imagebg">
                <img src="assets/media/add-circle-outline7.png" alt="Book Image">
                <img src="assets/media/trash-outline.png" alt="Book Image">

              </div>
            </div>
            
          </div>
        </div>
            <button class="btn-primary leftLst"><</button>
            <button class="btn-primary rightLst">></button>
    </div>
  </div>
</div> -->